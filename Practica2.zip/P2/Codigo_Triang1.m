% Reconstrucción de la señal con series de fourier
f = 2.5e3;
T = 1/f;
t = -1e-3:T/100:1.5e-3;
x1 = 2.432;
x3 = 0.27;
x5 = 9.727e-2;
x7 = 4.963e-2;
x9 = 3e-2;
x11 = 2.01e-2;
x13 = 1.439e-2;
x15 = 1.081e-2;
V1 = x1*cos(2*pi*f*t);
V3 = x3*cos(3*2*pi*f*t);
V5 = x5*cos(5*2*pi*f*t);
V7 = x7*cos(7*2*pi*f*t);
V9 = x9*cos(9*2*pi*f*t);
V11 = x11*cos(11*2*pi*f*t);
V13 = x13*cos(13*2*pi*f*t);
V15 = x15*cos(15*2*pi*f*t);
vt = V1+V3+V5+V7+V9+V11+V13+V15;

D = length(vt);                 % Longitud de la señal
VT = fft(vt);
VT2 = abs(VT/D);                 % Espectro de dos lados
VT1 = VT2(1:fix(D/2)+1);               % Espectro de un solo lado
VT1(2:end-1) = 2*VT1(2:end-1);    % Ajustar para simetria
fvt = (0:(D/2))/D;               % vector de frecuencia
% Obtener señal en el tiempo de archivo .csv
a0 = triangt1.E1;
t0 = triangt1.E3;
    % Obtener fft de la señal en tiempo
L = length(a0);                 % Longitud de la señal
A0 = fft(a0);
E2 = abs(A0/L);                 % Espectro de dos lados
E1 = E2(1:L/2+1);               % Espectro de un solo lado
E1(2:end-1) = 2*E1(2:end-1);    % Ajustar para simetria
f0 = (0:(L/2))/L;               % vector de frecuencia
    %Obtener señal en frecuencia de archivo .csv
A1 = triangfft1.VarName5;
f1 = triangfft1.VarName4;
    %Reconstrucción de la señal en tiempo
A1V = sqrt(2)*10.^(A1/20);      %Conversión de dB a V
N = length(f1);
A1_aprox = A1V .* exp(1j * zeros(size(N,1)));           % fase cero
A1_full = [A1_aprox; flipud(conj(A1_aprox(2:end-1)))];  % hacer simétrica
a1 = ifft(A1_full, 'symmetric');
fs = max(f1)*2;
t1 = (0:length(A1_full)-1)/fs;
    %Graficar
subplot(3,2,1);
plot(t,vt);
title 'Señal en Tiempo (Serie de Fourier)'
grid minor
xlabel 'Tiempo [s]'
ylabel 'Amplitud [V]'

subplot(3,2,2);
plot(fvt,VT1);
title 'Señal en Frecuencia (Serie de Fourier)'
grid minor
xlabel 'Frecuencia [Hz]'
ylabel 'Amplitud [V]'

subplot(3,2,3);
plot(t0,a0);
title 'Señal en Tiempo (.csv)'
grid minor
xlabel 'Tiempo [s]'
ylabel 'Amplitud [V]'

subplot(3,2,4)
plot(f0, E1);
title 'Señal en Frecuencia (Construida)'
grid minor
xlabel 'Frecuencia [Hz]'
ylabel 'Amplitud'

subplot(3,2,5);
plot(f1,A1);
title 'Señal en Frecuencia (.csv)'
grid minor
xlabel 'Frecuencia [Hz]'
ylabel 'Amplitud [dB]'

subplot(3,2,6);
plot(t1,a1);
title 'Señal en Tiempo (Reconstruida)'
grid minor
xlabel 'Tiempo'
ylabel 'Amplitud'
