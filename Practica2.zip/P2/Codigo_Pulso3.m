% Reconstrucción de la señal con series de fourier
f = 2.5e3;
T = 1/f;
w = 2*pi*f;
CT = 0.3;
tau = CT*T;
x = pi*(tau/T);
V = 3;
v = (V*tau)/T;
t = -1e-3:T/100:1e-3;
vt = v;

for n = 1:1:10
    vt = vt + (2*v)*(sin(n*x)/(n*x))*cos(n*w*t);
end

D = length(vt);                 % Longitud de la señal
VT = fft(vt);
VT2 = abs(VT/D);                 % Espectro de dos lados
VT1 = VT2(1:fix(D/2)+1);               % Espectro de un solo lado
VT1(2:end-1) = 2*VT1(2:end-1);    % Ajustar para simetria
fvt = (0:(D/2))/D;               % vector de frecuencia
% Obtener señal en el tiempo de archivo .csv
a0 = pulso3.VarName5;
t0 = pulso3.E3;
    % Obtener fft de la señal en tiempo
L = length(a0);                 % Longitud de la señal
A0 = fft(a0);
E2 = abs(A0/L);                 % Espectro de dos lados
E1 = E2(1:L/2+1);               % Espectro de un solo lado
E1(2:end-1) = 2*E1(2:end-1);    % Ajustar para simetria
f0 = (0:(L/2))/L;               % vector de frecuencia
    %Obtener señal en frecuencia de archivo .csv
A1 = pulso3fft.VarName5;
f1 = pulso3fft.VarName4;
    %Reconstrucción de la señal en tiempo
A1V = sqrt(2)*10.^(A1/20);      %Conversión de dB a V
N = length(f1);
A1_aprox = A1V .* exp(1j * zeros(size(N,1)));           % fase cero
A1_full = [A1_aprox; flipud(conj(A1_aprox(2:end-1)))];  % hacer simétrica
a1 = ifft(A1_full, 'symmetric');
fs = max(f1)*2;
t1 = (0:length(A1_full)-1)/fs;
    %Graficar
subplot(3,2,1);
plot(t,vt);
title 'Señal en Tiempo (Serie de Fourier)'
grid minor
xlabel 'Tiempo [s]'
ylabel 'Amplitud [V]'

subplot(3,2,2);
plot(fvt,VT1);
title 'Señal en Frecuencia (Serie de Fourier)'
grid minor
xlabel 'Frecuencia [Hz]'
ylabel 'Amplitud [V]'

subplot(3,2,3);
plot(t0,a0);
title 'Señal en Tiempo (.csv)'
grid minor
xlabel 'Tiempo [s]'
ylabel 'Amplitud [V]'

subplot(3,2,4)
plot(f0, E1);
title 'Señal en Frecuencia (Construida)'
grid minor
xlabel 'Frecuencia [Hz]'
ylabel 'Amplitud'

subplot(3,2,5);
plot(f1,A1);
title 'Señal en Frecuencia (.csv)'
grid minor
xlabel 'Frecuencia [Hz]'
ylabel 'Amplitud [dB]'

subplot(3,2,6);
plot(t1,a1);
title 'Señal en Tiempo (Reconstruida)'
grid minor
xlabel 'Tiempo'
ylabel 'Amplitud'