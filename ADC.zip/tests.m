archivo = '/MATLAB Drive/test5.txt';   
opts = detectImportOptions(archivo, 'Delimiter', '\t');  
datos = readmatrix(archivo, opts); 
voltaje = datos(:,2); 
media = mean(voltaje); 
desviacion = std(voltaje); 
fprintf('Media: %.4f\n', media); 
fprintf('Desviacion estandar: %.4f\n', desviacion); 