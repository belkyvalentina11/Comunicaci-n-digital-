datos = readmatrix('/MATLAB Drive/h5.txt');  
valores = datos(:,1); 
figure; 
histogram(valores, 20);
title('Histograma de Voltajes experimentales');
xlabel('Voltaje [V]'); 
ylabel('Frecuencia'); 
grid on; 