% ==== Lectura del archivo ====
data = readtable('/MATLAB Drive/adc_capture_250.csv');   % leer CSV

% ==== Extracción de datos ====
t = data.t_us * 1e-6;   % convertir microsegundos a segundos
V = data.volts;         % columna de voltajes

% ==== Calcular frecuencia de muestreo ====
Ts = mean(diff(t));     % periodo de muestreo promedio (s)
fs = 1/Ts;              % frecuencia de muestreo (Hz)

fprintf('Periodo de muestreo: %.6f s\n', Ts);
fprintf('Frecuencia de muestreo: %.2f Hz\n', fs);

% ==== Gráfica ====
figure('Position',[100 100 900 400]);  

% Dibujar las muestras
stem(t, V, 'r','filled','LineWidth',1.5); hold on;   

% Señal reconstruida (lineal entre muestras)
plot(t, V, 'b-','LineWidth',1.5);                    

xlabel('Tiempo (s)','FontSize',20,'FontWeight','bold');
ylabel('Voltaje (V)','FontSize',20,'FontWeight','bold');
title(sprintf('Muestreo y reconstrucción de la señal medida (f_s = %.1f Hz)', fs), ...
      'FontSize',20,'FontWeight','bold');

legend({'Muestras','Señal reconstruida'},'FontSize',14,'Location','best');
grid on;
set(gca,'FontSize',16,'LineWidth',1.2);
