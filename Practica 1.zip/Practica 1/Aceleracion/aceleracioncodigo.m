
t=B.Time_s_;
x=B.LinearAccelerationX_m_s_2_;
plot(t,x)

subplot(2,2,1)
t=B.Time_s_;
x=B.LinearAccelerationX_m_s_2_;
plot(t,x)

title('Aceleración lineal x')
xlabel('t(s)')
ylabel('a (m/s^2)')
plot(t,x)

subplot(2,2,2)
t=B.Time_s_;
x=B.LinearAccelerationY_m_s_2_;
plot(t,x)

xlabel('t(s)')
ylabel('a (m/s^2)')
title('Aceleración lineal y')

subplot(2,2,3)
t=B.Time_s_;
x=B.LinearAccelerationZ_m_s_2_;
plot(t,x)

xlabel('t(s)')
ylabel('a (m/s^2)')
title('Aceleración lineal z')

subplot(2,2,4)
t=B.Time_s_;
x=B.AbsoluteAcceleration_m_s_2_;
plot(t,x)

xlabel('t(s)')
ylabel('a (m/s^2)')
title('Aceleración absoluta')
