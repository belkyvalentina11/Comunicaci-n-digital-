t=data2.Time_s_;
t1=auto.TimeShift_s_;

subplot(2,2,1)
t=t;
x=data2.RotationX_rad_s_;
xlabel('t(s)')

subplot(2,2,1)
t=t;
x=data2.RotationX_rad_s_;
plot(t,x)
xlabel('t(s)')
ylabel('ω(rad/s)')
title('giroscopio x')

subplot(2,2,2)
t=t;
x=data2.RotationY_rad_s_;
plot(t,x)
xlabel('t(s)')
ylabel('ω(rad/s)')
title('giroscopio y')

subplot(2,2,3)
t=t;
x=data2.RotationZ_rad_s_;
plot(t,x)
xlabel('t(s)')
ylabel('ω(rad/s)')
title('giroscopio z')

subplot(2,2,4)
t=t1;
x=auto.AutocorrelationOfSum;
plot(t,x)

xlabel('Δ(s)')
ylabel('correlacion(a.u.')
title('autocorrelacion')