t=presionyvelocidad.Time_s_;
tv=presionyvelocidad.Time_velocity__s_;
ta=A1.Time_s_;

subplot(2,2,1)
t=t;
x=presionyvelocidad.Altitude_m_;
plot(t,x)
title('altitud')
xlabel('t(s)')
ylabel('h(m)')

subplot(2,2,2)
t=tv;
x=presionyvelocidad.Velocity_m_s_;
plot(t,x)
xlabel('t(s)')
ylabel('v(m/s)')
title('velocidad vertical')

subplot(2,2,3)
t=ta;
x=A1.Acceleration_m_s__;
plot(t,x)
xlabel('t(s)')
ylabel('v(m/s^2)')
title('aceleracion z')

subplot(2,2,4)
t=presionyvelocidad.Time_s_;
x=presionyvelocidad.Pressure_hPa_;
plot(t,x)
xlabel('t(s)')
ylabel('p(hPa)')
title('presion')

